import { useState, useEffect } from "react";

function App() {
  const [toDo, setToDo] = useState("");
  const [toDos, setToDos] = useState([]);
  const onChange = (event) => setToDo(event.target.value);
  const onSubmit = (event) => {
    event.preventDefault();
    if(toDo === "") {
      return;
    }
    setToDo("");
    setToDos(currentArray => [toDo, ...currentArray]);
  }
  console.log(toDos);
  return(
  <div>
    <h1>My To Dos({toDos.length})</h1>
    <form onSubmit={onSubmit}>
      <input 
        onChange ={onChange} 
        value={toDo} 
        type="text" 
        placeholder="Write your to do..." 
      />
      <button>Add To Do</button>
    </form>
  </div>
  );

}

export default App;



// import Button from "./Button";
// import styled from "./App.module.css"
// import { useState, useEffect } from "react";

// function Hello() {
//   function destroyedFn() {
//     console.log("bye");
//   }
//   function effectFn() {
//     console.log("created");
//     return destroyedFn;
//   }
//   useEffect(()=> {
//     console.log("hi");
//     return () => console.log("bye");
//   },[]);
//   // useEffect(function(){
//   // console.log("hi");
//   //  return   function (){
//   //    console.log("bye");
//   //  }
//   // },[]);
//   // useEffect(effectFn,[]);
//   return <h1>Hello</h1>;
// }

// function App() {
//   const [counter, setCounter] = useState(0);
//   const [keyword,setKeyword] = useState("");
//   const onClick = () => setCounter((prev) => prev + 1);
//   const onChange = (event) => setKeyword(event.target.value);
//   console.log("i run all the time");
//   const iRunOnlyOnce = () => {
//     console.log("i run only once");
//   }
//   const [showing,setShowing] = useState(false);
//   const onClick2 = () => setShowing((prev) => !prev);
//   useEffect(iRunOnlyOnce, []);
//   useEffect(() => {
//     if(keyword !== "" && keyword.length > 5){
//       console.log("SEARCH FOR", keyword);
//     };
//   }, [keyword]);

//   return (
//     <div>
//       <input value={keyword} onChange={onChange} type="text" placeholder="Search here..."/>
//       <h1 className={styled.title}>Punch back!</h1>
//       <h1>{counter}</h1>
//       <button onClick={onClick}>응애</button>
//       <div>
//         {showing ? <Hello /> : null}
//         <button onClick={onClick2}>{showing ? "Hide" : "Show"}</button>
//       </div>
//       {/* <Button text={"응애"} onClick={onClick}/> */}
//     </div>
//   );
// }

// export default App;
